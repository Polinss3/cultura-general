export type AdFormat = "banner" | "interstitial" | "rewarded";
export type AgeBracket = "adult" | "minor" | "unknown";
export interface Context {
  appId: string;
  ageBracket: AgeBracket;
  isPremium: boolean;
  platform: "ios" | "android" | "web";
  locale: "es" | "en";
  appVersion: string;
  testMode?: boolean;
}
export interface Frequency {
  maxPerSession: number;
  cooldownSeconds: number;
  maxPerHour: number;
}
export interface ManifestAd {
  campaignId: string;
  creativeId: string;
  advertiserName: string;
  format: AdFormat;
  mediaType: "image" | "video";
  mediaUrl: string;
  posterUrl?: string;
  altText: string;
  locale: "es" | "en";
  platform: "ios" | "android" | "web" | "all";
  width: number;
  height: number;
  durationSeconds?: number;
  priority: number;
  weight: number;
  rewardName?: string;
  rewardAmount?: number;
  rewardDurationSeconds?: number;
}
export interface ServedAd extends ManifestAd {
  trackingToken: string;
  clickUrl: string;
  rewardToken?: string;
  expiresAt: string;
  frequency: Frequency;
}
export interface Manifest {
  version: string | number;
  etag: string;
  ads: ManifestAd[];
  frequency: Frequency;
}
export type EventType =
  | "ad_render"
  | "impression"
  | "viewable_impression"
  | "view_start"
  | "view_heartbeat"
  | "video_start"
  | "video_25"
  | "video_50"
  | "video_75"
  | "video_complete"
  | "dismiss"
  | "rewarded_offer"
  | "rewarded_start"
  | "rewarded_complete"
  | "load_error"
  | "playback_error"
  | "redirect_error";
export interface AdEvent {
  schemaVersion: 1;
  type: EventType;
  eventId: string;
  sessionId: string;
  timestamp: string;
  appId: string;
  placementId: string;
  campaignId: string;
  creativeId: string;
  format: AdFormat;
  platform: Context["platform"];
  locale: Context["locale"];
  appVersion: string;
  durationVisibleMs?: number;
  videoProgress?: number;
  errorCode?: string;
}
export interface RewardResult {
  granted: boolean;
  receipt?: string;
  reward?: { name: string; amount: number };
}
export interface Visibility {
  foreground: boolean;
  focused: boolean;
  visibleFraction: number;
}
