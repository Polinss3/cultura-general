type AudioMixingMode = "mixWithOthers" | "duckOthers" | "auto" | "doNotMix";

type AdVideoAudioPlayer = {
  audioMixingMode: AudioMixingMode;
  muted: boolean;
};

/** Keep external music/podcasts playing while ads start silently. */
export function configureNonInterruptingAdAudio(player: AdVideoAudioPlayer) {
  player.audioMixingMode = "mixWithOthers";
  player.muted = true;
}
