import type {
  AdEvent,
  AdFormat,
  Context,
  EventType,
  Frequency,
  Manifest,
  ManifestAd,
  RewardResult,
  ServedAd,
  Visibility,
} from "./types";
export type * from "./types";

export interface ClientOptions {
  baseUrl: string;
  context: Context;
  fetch?: typeof fetch;
  /** Native consumers supply expo-crypto.randomUUID. Never supply a persistent ID. */
  randomUUID?: () => string;
  monotonicNow?: () => number;
  wallNow?: () => number;
  random?: () => number;
  maxQueuedEvents?: number;
  requestTimeoutMs?: number;
}
type QueueEntry = {
  token: string;
  event: AdEvent;
  attempts: number;
  nextAt: number;
};
export function chooseAd(
  ads: ManifestAd[],
  context: Context,
  format: AdFormat,
  random = Math.random,
): ManifestAd | undefined {
  if (context.ageBracket !== "adult" || context.isPremium !== false)
    return undefined;
  const eligible = ads.filter(
    (ad) =>
      ad.format === format &&
      ad.locale === context.locale &&
      (ad.platform === "all" || ad.platform === context.platform) &&
      ad.weight > 0 &&
      Number.isFinite(ad.weight) &&
      Number.isFinite(ad.priority),
  );
  const top = Math.max(...eligible.map((ad) => ad.priority));
  const candidates = eligible.filter((ad) => ad.priority === top);
  const sum = candidates.reduce((n, ad) => n + ad.weight, 0);
  let cursor = Math.min(1 - Number.EPSILON, Math.max(0, random())) * sum;
  return candidates.find((ad) => (cursor -= ad.weight) < 0);
}

/** No storage, cookies, device identifiers, fingerprinting or automatic background tasks. */
export class AdsClient {
  readonly baseUrl: string;
  private context: Context;
  private readonly transport: typeof fetch;
  readonly uuid: () => string;
  readonly now: () => number;
  readonly wallNow: () => number;
  private session: string;
  private generation = 0;
  private readonly options: ClientOptions;
  private cache = new Map<string, Manifest>();
  private frequency = new Map<
    string,
    { count: number; times: number[]; last?: number }
  >();
  private appFrequency: { count: number; times: number[]; last?: number } = {
    count: 0,
    times: [],
  };
  private queue: QueueEntry[] = [];
  private active = new Set<AdPresentation>();
  private pending = new Set<string>();
  private flushing?: Promise<void>;
  constructor(options: ClientOptions) {
    const url = new URL(options.baseUrl);
    if (
      url.protocol !== "https:" &&
      !(
        url.protocol === "http:" &&
        ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname)
      )
    )
      throw new Error("HTTPS required");
    if (
      url.username ||
      url.password ||
      url.search ||
      url.hash ||
      !["", "/"].includes(url.pathname)
    )
      throw new Error("baseUrl must be an origin");
    this.baseUrl = url.origin;
    this.options = options;
    this.context = { ...options.context };
    this.transport = options.fetch ?? globalThis.fetch.bind(globalThis);
    this.uuid = options.randomUUID ?? (() => globalThis.crypto.randomUUID());
    this.now = options.monotonicNow ?? (() => performance.now());
    this.wallNow = options.wallNow ?? Date.now;
    this.session = this.uuid();
  }
  get sessionId() {
    return this.session;
  }
  get eligible() {
    return (
      this.context.ageBracket === "adult" && this.context.isPremium === false
    );
  }
  get queuedEvents() {
    return this.queue.length;
  }
  get currentContext(): Readonly<Context> {
    return { ...this.context };
  }
  updateContext(context: Partial<Context>) {
    this.context = { ...this.context, ...context };
    this.generation++;
    this.cache.clear();
    for (const item of this.active) item.invalidate();
    this.active.clear();
    this.queue = [];
  }
  /** Explicit app-session boundary, never call per placement or per request. */
  resetSession() {
    this.updateContext({});
    this.session = this.uuid();
    // Hourly limits survive session renewal while the process remains alive.
    for (const entry of this.frequency.values()) entry.count = 0;
    this.appFrequency.count = 0;
  }
  dispose() {
    this.updateContext({ ageBracket: "unknown" });
  }
  async post<T>(
    path: string,
    body: unknown,
    etag?: string,
  ): Promise<{ data?: T; notModified: boolean }> {
    const controller = new AbortController();
    const timeout = setTimeout(
      () => controller.abort(),
      this.options.requestTimeoutMs ?? 8000,
    );
    try {
      const response = await this.transport(`${this.baseUrl}/api/v1/${path}`, {
        method: "POST",
        credentials: "omit",
        redirect: "error",
        referrerPolicy: "no-referrer",
        signal: controller.signal,
        headers: {
          "content-type": "application/json",
          ...(etag ? { "if-none-match": etag } : {}),
        },
        body: JSON.stringify(body),
      });
      if (response.status === 304) return { notModified: true };
      if (!response.ok) throw new HttpError(response.status);
      return { data: (await response.json()) as T, notModified: false };
    } finally {
      clearTimeout(timeout);
    }
  }
  /**
   * The app-wide budget only governs the ads the app pushes at the user, and
   * that is the interstitial. A rewarded ad is the user's own request and a
   * banner interrupts nothing, so both are capped by their placement alone: a
   * banner requested on entering a screen must never refuse a hint asked for
   * seconds later, nor eat the interstitial's share of a long session.
   */
  private permitted(placementId: string, format: AdFormat, limits: Frequency) {
    if (
      ![
        limits?.maxPerSession,
        limits?.maxPerHour,
        limits?.cooldownSeconds,
      ].every((n) => Number.isFinite(n) && n >= 0)
    )
      return false;
    const entries =
      format === "interstitial"
        ? [this.appFrequency, this.frequency.get(placementId)]
        : [this.frequency.get(placementId)];
    return entries.every((entry) => {
      if (!entry) return limits.maxPerSession > 0 && limits.maxPerHour > 0;
      entry.times = entry.times.filter((t) => t > this.now() - 3_600_000);
      return (
        entry.count < limits.maxPerSession &&
        entry.times.length < limits.maxPerHour &&
        (entry.last === undefined ||
          this.now() - entry.last >= limits.cooldownSeconds * 1000)
      );
    });
  }
  async request(options: {
    placementId: string;
    format: AdFormat;
    naturalBreak?: boolean;
    voluntary?: boolean;
  }): Promise<AdPresentation | null> {
    if (
      !this.eligible ||
      this.pending.has(options.placementId) ||
      this.pending.size >= 16 ||
      this.active.size > 0 ||
      (!this.frequency.has(options.placementId) &&
        this.frequency.size >= 256) ||
      (options.format === "interstitial" && options.naturalBreak !== true) ||
      (options.format === "rewarded" && options.voluntary !== true)
    )
      return null;
    const generation = this.generation;
    const context = {
      ...this.context,
      placementId: options.placementId,
      sessionId: this.session,
    };
    this.pending.add(options.placementId);
    try {
      const cached = this.cache.get(options.placementId);
      const response = await this.post<Manifest>(
        "manifest",
        context,
        cached?.etag,
      );
      if (generation !== this.generation || !this.eligible) return null;
      const manifest = response.notModified ? cached : response.data;
      if (
        !manifest ||
        !Array.isArray(manifest.ads) ||
        !this.permitted(options.placementId, options.format, manifest.frequency)
      )
        return null;
      // Every request revalidates the manifest; there is no offline/stale serving.
      if (this.cache.size >= 64 && !this.cache.has(options.placementId))
        this.cache.delete(this.cache.keys().next().value!);
      this.cache.set(options.placementId, manifest);
      const selected = chooseAd(
        manifest.ads,
        this.context,
        options.format,
        this.options.random,
      );
      if (!selected) return null;
      const served = await this.post<{ ad: ServedAd | null }>("serve", {
        ...context,
        creativeId: selected.creativeId,
      });
      const ad = served.data?.ad;
      if (
        generation !== this.generation ||
        !this.eligible ||
        !ad ||
        this.active.size > 0 ||
        ad.format !== options.format ||
        ad.locale !== this.context.locale ||
        !["all", this.context.platform].includes(ad.platform) ||
        !Number.isFinite(Date.parse(ad.expiresAt)) ||
        Date.parse(ad.expiresAt) <= this.wallNow() ||
        !this.permitted(options.placementId, options.format, ad.frequency) ||
        typeof ad.trackingToken !== "string" ||
        !ad.trackingToken
      )
        return null;
      for (const media of [ad.mediaUrl, ad.posterUrl].filter(
        Boolean,
      ) as string[]) {
        const url = new URL(media, this.baseUrl);
        if (
          url.origin !== this.baseUrl ||
          !url.pathname.startsWith("/media/") ||
          url.search ||
          url.hash
        )
          return null;
      }
      const entry = this.frequency.get(options.placementId) ?? {
        count: 0,
        times: [],
      };
      if (entry.times.length >= 1000 || this.appFrequency.times.length >= 1000)
        return null;
      entry.count++;
      entry.last = this.now();
      entry.times.push(entry.last);
      this.frequency.set(options.placementId, entry);
      // Only an interstitial spends the app-wide budget. A served rewarded
      // just restarts the app-wide cooldown, so an automatic interstitial
      // cannot chain right behind the video; a banner touches nothing.
      if (options.format === "interstitial") {
        this.appFrequency.count++;
        this.appFrequency.last = entry.last;
        this.appFrequency.times.push(entry.last);
      } else if (options.format === "rewarded") {
        this.appFrequency.last = entry.last;
      }
      const presentation = new AdPresentation(this, ad, context);
      this.active.add(presentation);
      return presentation;
    } catch {
      return null;
    } finally {
      this.pending.delete(options.placementId);
    }
  }
  release(presentation: AdPresentation) {
    this.active.delete(presentation);
  }
  enqueue(token: string, event: AdEvent) {
    if (!this.eligible) return;
    const max = Math.max(
      1,
      Math.min(1000, this.options.maxQueuedEvents ?? 200),
    );
    if (this.queue.length >= max) this.queue.shift();
    this.queue.push({ token, event, attempts: 0, nextAt: this.now() });
  }
  flush(): Promise<void> {
    if (this.flushing) return this.flushing;
    this.flushing = this.drain().finally(() => {
      this.flushing = undefined;
    });
    return this.flushing;
  }
  private async drain() {
    // A bounded snapshot avoids starvation when new events arrive during a request.
    const snapshot = [...this.queue];
    for (const token of new Set(snapshot.map((item) => item.token))) {
      const group = snapshot.filter((item) => item.token === token);
      if (group[0].nextAt > this.now()) continue;
      for (let offset = 0; offset < group.length; offset += 25) {
        const batch = group
          .slice(offset, offset + 25)
          .filter((item) => this.queue.includes(item));
        if (!batch.length || !this.eligible) continue;
        try {
          await this.post("events", {
            trackingToken: token,
            events: batch.map((item) => item.event),
          });
          this.queue = this.queue.filter((item) => !batch.includes(item));
        } catch (error) {
          for (const item of batch) {
            item.attempts++;
            item.nextAt =
              this.now() + Math.min(60_000, 1000 * 2 ** item.attempts);
          }
          this.queue = this.queue.filter(
            (item) =>
              !batch.includes(item) ||
              (!(
                error instanceof HttpError &&
                error.status >= 400 &&
                error.status < 500 &&
                error.status !== 429
              ) &&
                item.attempts < 5),
          );
          // Cumulative progress must be delivered in order, including after retries.
          break;
        }
      }
    }
  }
}
class HttpError extends Error {
  constructor(readonly status: number) {
    super(`HTTP ${status}`);
  }
}

export class AdPresentation {
  private ended = false;
  private loaded = false;
  private visibility: Visibility = {
    foreground: false,
    focused: false,
    visibleFraction: 0,
  };
  private last: number;
  private elapsed = 0;
  private continuous = 0;
  private lastHeartbeat = 0;
  private sent = new Set<EventType>();
  private progress = 0;
  private playing = false;
  private rewardEventId: string;
  private rewardResult?: RewardResult;
  private rewardPending?: Promise<RewardResult>;
  constructor(
    private client: AdsClient,
    readonly ad: ServedAd,
    private context: Context & { placementId: string; sessionId: string },
  ) {
    this.last = client.now();
    this.rewardEventId = client.uuid();
    if (ad.format === "rewarded") {
      this.emit("rewarded_offer");
      this.emit("rewarded_start");
    }
  }
  get valid() {
    return (
      !this.ended &&
      this.client.eligible &&
      this.context.sessionId === this.client.sessionId &&
      this.client.wallNow() < Date.parse(this.ad.expiresAt)
    );
  }
  get visibleMs() {
    return Math.floor(this.elapsed);
  }
  get rewardReady() {
    return (
      this.valid &&
      this.ad.format === "rewarded" &&
      this.visibleMs >=
        (this.ad.rewardDurationSeconds ?? this.ad.durationSeconds ?? 5) *
          1000 &&
      (this.ad.mediaType !== "video" || this.progress >= 0.99)
    );
  }
  private get visible() {
    return (
      this.valid &&
      this.loaded &&
      this.visibility.foreground &&
      this.visibility.focused &&
      this.visibility.visibleFraction >= 0.5 &&
      (this.ad.mediaType !== "video" || this.playing)
    );
  }
  private emit(
    type: EventType,
    extra: Partial<Pick<AdEvent, "errorCode">> = {},
  ) {
    if (!this.valid) return;
    this.client.enqueue(this.ad.trackingToken, {
      schemaVersion: 1,
      type,
      eventId: this.client.uuid(),
      sessionId: this.context.sessionId,
      timestamp: new Date(this.client.wallNow()).toISOString(),
      appId: this.context.appId,
      placementId: this.context.placementId,
      campaignId: this.ad.campaignId,
      creativeId: this.ad.creativeId,
      format: this.ad.format,
      platform: this.context.platform,
      locale: this.context.locale,
      appVersion: this.context.appVersion,
      durationVisibleMs: this.visibleMs,
      videoProgress: this.progress,
      ...extra,
    });
  }
  private once(type: EventType) {
    if (!this.sent.has(type)) {
      this.sent.add(type);
      this.emit(type);
    }
  }
  rendered() {
    if (!this.valid || this.loaded) return;
    this.loaded = true;
    this.last = this.client.now();
    this.once("ad_render");
  }
  setVisibility(visibility: Visibility) {
    this.tick();
    this.visibility = {
      ...visibility,
      visibleFraction: Number.isFinite(visibility.visibleFraction)
        ? Math.min(1, Math.max(0, visibility.visibleFraction))
        : 0,
    };
    if (!this.visible) this.continuous = 0;
    this.tick();
  }
  /** Call at least every second while mounted. Gaps over 2s never add unseen/background time. */
  tick() {
    const now = this.client.now();
    const delta = Math.max(0, now - this.last);
    this.last = now;
    if (!this.visible) {
      this.continuous = 0;
      return;
    }
    if (delta <= 2000) {
      this.elapsed += delta;
      this.continuous += delta;
    } else this.continuous = 0;
    this.once("impression");
    this.once("view_start");
    if (this.continuous >= (this.ad.mediaType === "video" ? 2000 : 1000))
      this.once("viewable_impression");
    if (this.elapsed - this.lastHeartbeat >= 5000) {
      this.lastHeartbeat = this.elapsed;
      this.emit("view_heartbeat");
      void this.client.flush();
    }
  }
  videoProgress(seconds: number, duration: number, playing: boolean) {
    this.tick();
    this.playing = playing;
    if (
      !this.valid ||
      !this.loaded ||
      !this.visibility.foreground ||
      !this.visibility.focused ||
      this.visibility.visibleFraction < 0.5 ||
      !playing ||
      duration <= 0 ||
      !Number.isFinite(seconds) ||
      !Number.isFinite(duration)
    )
      return;
    this.progress = Math.max(
      this.progress,
      Math.min(1, Math.max(0, seconds / duration)),
    );
    if (seconds > 0) this.once("video_start");
    for (const [threshold, type] of [
      [0.25, "video_25"],
      [0.5, "video_50"],
      [0.75, "video_75"],
      [0.99, "video_complete"],
    ] as const)
      if (this.progress >= threshold) this.once(type);
  }
  error(
    type: "load_error" | "playback_error" | "redirect_error",
    code: string,
  ) {
    const allowed = [
      "network",
      "load_failed",
      "playback_failed",
      "redirect_failed",
      "timeout",
      "unsupported",
      "unknown",
    ];
    this.emit(type, {
      errorCode: allowed.includes(code.toLowerCase())
        ? code.toLowerCase()
        : "unknown",
    });
  }
  clickUrl() {
    if (!this.valid) return null;
    const url = new URL(this.ad.clickUrl, this.client.baseUrl);
    return url.origin === this.client.baseUrl &&
      /^\/r\/[A-Za-z0-9_.-]+$/.test(url.pathname) &&
      !url.search &&
      !url.hash
      ? url.href
      : null;
  }
  mediaUrl(path: string) {
    const url = new URL(path, this.client.baseUrl);
    if (
      url.origin !== this.client.baseUrl ||
      !url.pathname.startsWith("/media/") ||
      url.search ||
      url.hash
    )
      throw new Error("Untrusted media URL");
    return url.href;
  }
  async completeReward(): Promise<RewardResult> {
    if (this.rewardResult?.granted) return this.rewardResult;
    if (this.rewardPending) return this.rewardPending;
    this.tick();
    if (!this.rewardReady || !this.ad.rewardToken) return { granted: false };
    this.once("rewarded_complete");
    this.emit("view_heartbeat");
    this.rewardPending = (async () => {
      await this.client.flush();
      if (!this.valid) return { granted: false };
      try {
        const result = await this.client.post<RewardResult>(
          "rewards/complete",
          {
            rewardToken: this.ad.rewardToken,
            trackingToken: this.ad.trackingToken,
            eventId: this.rewardEventId,
          },
        );
        this.rewardResult = result.data ?? { granted: false };
        return this.rewardResult;
      } catch {
        return { granted: false };
      }
    })().finally(() => {
      this.rewardPending = undefined;
    });
    return this.rewardPending;
  }
  dismiss() {
    this.tick();
    this.emit("view_heartbeat");
    this.once("dismiss");
    this.invalidate();
    void this.client.flush();
  }
  invalidate() {
    this.ended = true;
    this.visibility.foreground = false;
    this.client.release(this);
  }
}
