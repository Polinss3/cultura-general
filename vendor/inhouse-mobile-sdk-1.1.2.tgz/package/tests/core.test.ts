import { describe, expect, it } from "vitest";
import {
  AdsClient,
  chooseAd,
  type Context,
  type ManifestAd,
  type ServedAd,
} from "../src/index";

const context: Context = {
  appId: "app",
  ageBracket: "adult",
  isPremium: false,
  platform: "web",
  locale: "es",
  appVersion: "1",
};
const creative: ManifestAd = {
  campaignId: "campaign",
  creativeId: "creative",
  advertiserName: "House",
  format: "interstitial",
  mediaType: "image",
  mediaUrl: "/media/example.png",
  altText: "Example",
  locale: "es",
  platform: "all",
  width: 100,
  height: 100,
  priority: 1,
  weight: 1,
};
const frequency = { maxPerSession: 3, maxPerHour: 6, cooldownSeconds: 120 };
function harness(
  overrides: Partial<Context> = {},
  adOverride: Partial<ServedAd> = {},
  opts: {
    maxQueuedEvents?: number;
    rewardedFrequency?: ServedAd["frequency"];
    bannerFrequency?: ServedAd["frequency"];
  } = {},
) {
  let clock = 0;
  let serial = 0;
  let failEvents = false;
  let failReward = false;
  let use304 = false;
  const requests: {
    path: string;
    body: any;
    headers: HeadersInit | undefined;
  }[] = [];
  const ad: ServedAd = {
    ...creative,
    trackingToken: "token",
    rewardToken: "reward",
    clickUrl: "/r/signed.token",
    expiresAt: new Date(1_800_000_000_000).toISOString(),
    frequency,
    ...adOverride,
  };
  // The manifest carries one creative per format; serve answers with the one
  // the client chose, as the real server does. Rewarded placements report
  // their own limits, never the app-wide ones.
  const rewarded: ServedAd = {
    ...ad,
    creativeId: "rewarded-creative",
    format: "rewarded",
    rewardDurationSeconds: 1,
    frequency: opts.rewardedFrequency ?? {
      maxPerSession: 100,
      maxPerHour: 100,
      cooldownSeconds: 0,
    },
  };
  const banner: ServedAd = {
    ...ad,
    creativeId: "banner-creative",
    format: "banner",
    frequency: opts.bannerFrequency ?? {
      maxPerSession: 100,
      maxPerHour: 100,
      cooldownSeconds: 0,
    },
  };
  const byCreative = (id: string) =>
    id === rewarded.creativeId
      ? rewarded
      : id === banner.creativeId
        ? banner
        : ad;
  const client = new AdsClient({
    baseUrl: "https://ads.example.com",
    context: { ...context, ...overrides },
    monotonicNow: () => clock,
    wallNow: () => 1_700_000_000_000 + clock,
    randomUUID: () => `uuid-${++serial}`,
    ...opts,
    fetch: (async (url, init) => {
      const path = String(url).split("/").at(-1)!;
      requests.push({
        path,
        body: JSON.parse(init?.body as string),
        headers: init?.headers,
      });
      const body = JSON.parse(init?.body as string);
      if (path === "manifest")
        return use304
          ? new Response(null, { status: 304 })
          : Response.json({
              version: 1,
              etag: "v1",
              ads: [ad, rewarded, banner],
              frequency:
                body.placementId === rewardedRequest.placementId
                  ? rewarded.frequency
                  : body.placementId === bannerRequest.placementId
                    ? banner.frequency
                    : ad.frequency,
            });
      if (path === "serve")
        return Response.json({ ad: byCreative(body.creativeId) });
      if (path === "events") {
        if (failEvents) throw new Error("offline");
        return Response.json({ accepted: 25, duplicates: 0 });
      }
      if (path === "complete") {
        if (failReward) throw new Error("offline");
        return Response.json({
          granted: true,
          receipt: "receipt",
          reward: { name: "coins", amount: 5 },
        });
      }
      throw new Error(`Unexpected request ${path}`);
    }) as typeof fetch,
  });
  return {
    client,
    requests,
    ad,
    advance: (ms: number) => {
      clock += ms;
    },
    eventsFail: (value: boolean) => {
      failEvents = value;
    },
    rewardFail: (value: boolean) => {
      failReward = value;
    },
    use304: () => {
      use304 = true;
    },
  };
}
const request = {
  placementId: "placement",
  format: "interstitial" as const,
  naturalBreak: true,
};
const rewardedRequest = {
  placementId: "rewarded-placement",
  format: "rewarded" as const,
  voluntary: true,
};
const bannerRequest = {
  placementId: "banner-placement",
  format: "banner" as const,
};

describe("eligibility and session boundaries", () => {
  it.each([
    { ageBracket: "minor" },
    { ageBracket: "unknown" },
    { isPremium: true },
    { isPremium: undefined },
  ])("does not contact API for excluded context %j", async (override) => {
    const h = harness(override as Partial<Context>);
    expect(await h.client.request(request)).toBeNull();
    expect(h.requests).toHaveLength(0);
  });
  it("requires a natural break and voluntary rewarded offer", async () => {
    const h = harness();
    expect(
      await h.client.request({ ...request, naturalBreak: false }),
    ).toBeNull();
    expect(
      await h.client.request({ ...request, format: "rewarded" }),
    ).toBeNull();
    expect(h.requests).toHaveLength(0);
  });
  it("invalidates loaded ads immediately when premium changes", async () => {
    const h = harness();
    const presentation = await h.client.request(request);
    h.client.updateContext({ isPremium: true });
    expect(presentation?.valid).toBe(false);
    expect(presentation?.clickUrl()).toBeNull();
    expect(h.client.queuedEvents).toBe(0);
  });
  it("renews session IDs while preserving process hourly frequency", async () => {
    const h = harness(
      {},
      { frequency: { maxPerSession: 1, maxPerHour: 1, cooldownSeconds: 0 } },
    );
    const first = await h.client.request(request);
    first!.dismiss();
    const session = h.client.sessionId;
    h.client.resetSession();
    expect(h.client.sessionId).not.toBe(session);
    expect(await h.client.request(request)).toBeNull();
    h.advance(3_600_001);
    expect(await h.client.request(request)).not.toBeNull();
  });
  it("rejects a late response after eligibility changes", async () => {
    const h = harness();
    const pending = h.client.request(request);
    h.client.updateContext({ ageBracket: "minor" });
    expect(await pending).toBeNull();
    expect(h.requests.some((r) => r.path === "serve")).toBe(false);
  });
  it("applies the app frequency across different placements locally", async () => {
    const h = harness(
      {},
      { frequency: { maxPerSession: 1, maxPerHour: 10, cooldownSeconds: 0 } },
    );
    (await h.client.request(request))!.dismiss();
    expect(
      await h.client.request({ ...request, placementId: "another-placement" }),
    ).toBeNull();
    expect(h.requests.filter((r) => r.path === "serve")).toHaveLength(1);
  });
});
describe("banner frequency", () => {
  it("neither spends the app-wide budget nor starts its cooldown, and is capped by its placement alone", async () => {
    // A long session opens many game screens, each requesting a banner. That
    // must not eat the interstitial's share nor delay it.
    const h = harness(
      {},
      { frequency: { maxPerSession: 1, maxPerHour: 1, cooldownSeconds: 120 } },
      {
        bannerFrequency: {
          maxPerSession: 3,
          maxPerHour: 100,
          cooldownSeconds: 0,
        },
      },
    );
    (await h.client.request(bannerRequest))!.dismiss();
    (await h.client.request(bannerRequest))!.dismiss();
    (await h.client.request(request))!.dismiss();
    // The interstitial is now spent and cooling down; banners carry on.
    expect(await h.client.request(request)).toBeNull();
    (await h.client.request(bannerRequest))!.dismiss();
    expect(await h.client.request(bannerRequest)).toBeNull();
    expect(h.requests.filter((r) => r.path === "serve")).toHaveLength(4);
  });
});
describe("voluntary rewarded frequency", () => {
  it("is never refused by the app-wide budget or cooldown spent by pushed placements", async () => {
    // The 101 Games report: a banner served on entering the game, then a hint
    // asked for 4 s later was refused by a 5 s cooldown the hint never started.
    const h = harness(
      {},
      { frequency: { maxPerSession: 1, maxPerHour: 1, cooldownSeconds: 120 } },
      {
        rewardedFrequency: {
          maxPerSession: 20,
          maxPerHour: 40,
          cooldownSeconds: 5,
        },
      },
    );
    (await h.client.request(request))!.dismiss();
    h.advance(4_000);
    expect(
      await h.client.request({ ...request, placementId: "another-placement" }),
    ).toBeNull();
    const first = await h.client.request(rewardedRequest);
    expect(first).not.toBeNull();
    first!.dismiss();
    h.advance(5_000);
    const second = await h.client.request(rewardedRequest);
    expect(second).not.toBeNull();
    second!.dismiss();
    expect(h.requests.filter((r) => r.path === "serve")).toHaveLength(3);
  });
  it("is capped by its own placement limits alone", async () => {
    const h = harness(
      {},
      { frequency: { maxPerSession: 1, maxPerHour: 1, cooldownSeconds: 0 } },
      {
        rewardedFrequency: {
          maxPerSession: 2,
          maxPerHour: 100,
          cooldownSeconds: 30,
        },
      },
    );
    (await h.client.request(request))!.dismiss();
    (await h.client.request(rewardedRequest))!.dismiss();
    expect(await h.client.request(rewardedRequest)).toBeNull();
    h.advance(30_000);
    (await h.client.request(rewardedRequest))!.dismiss();
    h.advance(30_000);
    expect(await h.client.request(rewardedRequest)).toBeNull();
    expect(h.requests.filter((r) => r.path === "serve")).toHaveLength(3);
  });
  it("restarts the app-wide cooldown without spending the app-wide budget", async () => {
    const h = harness(
      {},
      { frequency: { maxPerSession: 2, maxPerHour: 10, cooldownSeconds: 10 } },
    );
    (await h.client.request(rewardedRequest))!.dismiss();
    h.advance(5_000);
    // An automatic interstitial must not chain right behind the video.
    expect(await h.client.request(request)).toBeNull();
    h.advance(5_000);
    (await h.client.request(request))!.dismiss();
    h.advance(10_000);
    // Second pushed ad still fits: the rewarded did not count as one.
    (await h.client.request(request))!.dismiss();
    h.advance(10_000);
    expect(await h.client.request(request)).toBeNull();
    expect(h.requests.filter((r) => r.path === "serve")).toHaveLength(3);
  });
});
describe("selection, cache and delivery", () => {
  it("restricts locale/platform/priority and weights selection", () => {
    const ads = [
      { ...creative, creativeId: "a", weight: 1 },
      { ...creative, creativeId: "b", weight: 3 },
      { ...creative, creativeId: "lower", priority: 0, weight: 100 },
      {
        ...creative,
        creativeId: "foreign",
        locale: "en" as const,
        priority: 10,
      },
    ];
    expect(chooseAd(ads, context, "interstitial", () => 0.1)?.creativeId).toBe(
      "a",
    );
    expect(chooseAd(ads, context, "interstitial", () => 0.8)?.creativeId).toBe(
      "b",
    );
    expect(chooseAd(ads, context, "banner")).toBeUndefined();
    expect(
      chooseAd(ads, { ...context, isPremium: true }, "interstitial"),
    ).toBeUndefined();
  });
  it("uses ETag only after online manifest revalidation and enforces cooldown", async () => {
    const h = harness();
    (await h.client.request(request))!.dismiss();
    expect(await h.client.request(request)).toBeNull();
    h.advance(120_000);
    h.use304();
    expect(await h.client.request(request)).not.toBeNull();
    expect(
      h.requests.filter((r) => r.path === "manifest").at(-1)?.headers,
    ).toMatchObject({ "if-none-match": "v1" });
  });
  it("only opens server signed same-origin redirect URLs", async () => {
    const h = harness({}, { clickUrl: "https://evil.example/r/token" });
    const presentation = await h.client.request(request);
    expect(presentation!.clickUrl()).toBeNull();
    expect(() =>
      presentation!.mediaUrl("https://evil.example/media/ad.png"),
    ).toThrow();
  });
});
describe("visible measurement and event queue", () => {
  it("does not count downloaded or hidden ads; pauses for background and timer suspension", async () => {
    const h = harness();
    const p = (await h.client.request(request))!;
    h.advance(1000);
    p.tick();
    expect(p.visibleMs).toBe(0);
    p.rendered();
    p.setVisibility({ foreground: true, focused: true, visibleFraction: 0.49 });
    h.advance(1000);
    p.tick();
    expect(p.visibleMs).toBe(0);
    p.setVisibility({ foreground: true, focused: true, visibleFraction: 0.5 });
    h.advance(1000);
    p.tick();
    expect(p.visibleMs).toBe(1000);
    p.setVisibility({ foreground: false, focused: true, visibleFraction: 1 });
    h.advance(5000);
    p.tick();
    expect(p.visibleMs).toBe(1000);
    p.setVisibility({ foreground: true, focused: true, visibleFraction: 1 });
    h.advance(20_000);
    p.tick();
    expect(p.visibleMs).toBe(1000);
    await h.client.flush();
    const events = h.requests
      .filter((r) => r.path === "events")
      .flatMap((r) => r.body.events);
    expect(events.filter((e) => e.type === "impression")).toHaveLength(1);
    expect(events.filter((e) => e.type === "viewable_impression")).toHaveLength(
      1,
    );
  });
  it("requires continuous viewability and ignores invalid visibility fractions", async () => {
    const h = harness();
    const p = (await h.client.request(request))!;
    p.rendered();
    p.setVisibility({ foreground: true, focused: true, visibleFraction: 1 });
    h.advance(500);
    p.tick();
    p.setVisibility({ foreground: false, focused: true, visibleFraction: 1 });
    p.setVisibility({ foreground: true, focused: true, visibleFraction: 1 });
    h.advance(500);
    p.tick();
    p.setVisibility({ foreground: true, focused: true, visibleFraction: NaN });
    h.advance(1000);
    p.tick();
    await h.client.flush();
    expect(
      h.requests
        .flatMap((r) => r.body.events ?? [])
        .some((e) => e.type === "viewable_impression"),
    ).toBe(false);
  });
  it("bounds memory, retries the same IDs with backoff, and avoids concurrent duplicate flushes", async () => {
    const h = harness({}, {}, { maxQueuedEvents: 5 });
    const p = (await h.client.request(request))!;
    for (let i = 0; i < 20; i++) p.error("load_error", "failed");
    expect(h.client.queuedEvents).toBe(5);
    h.eventsFail(true);
    await Promise.all([h.client.flush(), h.client.flush()]);
    expect(h.requests.filter((r) => r.path === "events")).toHaveLength(1);
    const ids = h.requests
      .at(-1)!
      .body.events.map((e: { eventId: string }) => e.eventId);
    await h.client.flush();
    expect(h.requests.filter((r) => r.path === "events")).toHaveLength(1);
    h.advance(2000);
    h.eventsFail(false);
    await h.client.flush();
    expect(
      h.requests.at(-1)!.body.events.map((e: { eventId: string }) => e.eventId),
    ).toEqual(ids);
    expect(h.client.queuedEvents).toBe(0);
  });
  it("keeps newer cumulative progress behind a failed batch", async () => {
    const h = harness();
    const p = (await h.client.request(request))!;
    p.rendered();
    h.eventsFail(true);
    await h.client.flush();
    p.setVisibility({ foreground: true, focused: true, visibleFraction: 1 });
    h.advance(1000);
    p.tick();
    await h.client.flush();
    expect(h.requests.filter((r) => r.path === "events")).toHaveLength(1);
    h.advance(1000);
    h.eventsFail(false);
    await h.client.flush();
    const types = h.requests
      .filter((r) => r.path === "events")
      .at(-1)!
      .body.events.map((event: { type: string }) => event.type);
    expect(types[0]).toBe("ad_render");
    expect(types).toContain("impression");
  });
});
describe("reward verification", () => {
  it("requires foreground visible duration, flushes evidence, retries same grant key, and caches receipt", async () => {
    const h = harness({}, { format: "rewarded", rewardDurationSeconds: 3 });
    const p = (await h.client.request({
      ...request,
      format: "rewarded",
      voluntary: true,
    }))!;
    expect(await p.completeReward()).toEqual({ granted: false });
    p.rendered();
    p.setVisibility({ foreground: true, focused: true, visibleFraction: 1 });
    for (let i = 0; i < 3; i++) {
      h.advance(1000);
      p.tick();
    }
    h.rewardFail(true);
    expect(await p.completeReward()).toEqual({ granted: false });
    const firstId = h.requests.find((r) => r.path === "complete")!.body.eventId;
    h.rewardFail(false);
    const granted = await p.completeReward();
    expect(granted.receipt).toBe("receipt");
    expect(
      h.requests.filter((r) => r.path === "complete").at(-1)!.body.eventId,
    ).toBe(firstId);
    expect(h.requests.findIndex((r) => r.path === "events")).toBeLessThan(
      h.requests.findIndex((r) => r.path === "complete"),
    );
    await p.completeReward();
    expect(h.requests.filter((r) => r.path === "complete")).toHaveLength(2);
  });
  it("does not reward a video just for being mounted or seeking while hidden", async () => {
    const h = harness(
      {},
      {
        format: "rewarded",
        mediaType: "video",
        durationSeconds: 3,
        rewardDurationSeconds: 3,
      },
    );
    const p = (await h.client.request({
      ...request,
      format: "rewarded",
      voluntary: true,
    }))!;
    p.rendered();
    p.videoProgress(3, 3, true);
    h.advance(3000);
    p.tick();
    expect(p.rewardReady).toBe(false);
    p.setVisibility({ foreground: true, focused: true, visibleFraction: 1 });
    p.videoProgress(0, 3, true);
    for (let i = 1; i <= 3; i++) {
      h.advance(1000);
      p.videoProgress(i, 3, true);
    }
    expect(p.rewardReady).toBe(true);
  });
});
