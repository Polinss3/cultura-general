import { describe, expect, it } from "vitest";
import { configureNonInterruptingAdAudio } from "../src/react-native-video";

describe("native ad video audio", () => {
  it("starts muted without taking audio focus from other apps", () => {
    const player = {
      audioMixingMode: "doNotMix" as const,
      muted: false,
    };

    configureNonInterruptingAdAudio(player);

    expect(player).toEqual({
      audioMixingMode: "mixWithOthers",
      muted: true,
    });
  });
});
