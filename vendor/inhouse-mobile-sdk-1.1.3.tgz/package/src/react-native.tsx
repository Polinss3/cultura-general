/** Optional adapter. Install native peers with `npx expo install` in the host app. */
import React, { useEffect, useRef, useState } from "react";
import {
  AccessibilityInfo,
  Alert,
  AppState,
  Linking,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
  type StyleProp,
  type ViewStyle,
} from "react-native";
import { Image } from "expo-image";
import { useVideoPlayer, VideoView } from "expo-video";
import { randomUUID } from "expo-crypto";
import { fetch as expoFetch } from "expo/fetch";
import { GlassView, isLiquidGlassAvailable } from "expo-glass-effect";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  AdsClient,
  type AdPresentation,
  type ClientOptions,
  type RewardResult,
} from "./index";
import { rewardCountdownDurationSeconds } from "./react-native-countdown";
import { configureNonInterruptingAdAudio } from "./react-native-video";

export function createNativeAdsClient(
  options: Omit<ClientOptions, "randomUUID" | "fetch">,
) {
  return new AdsClient({
    ...options,
    randomUUID,
    fetch: expoFetch as typeof fetch,
  });
}

export interface AdViewProps {
  presentation: AdPresentation;
  /** Must reflect navigation focus AND any host overlay occluding this ad. Defaults fail closed. */
  focused: boolean;
  onClose: () => void;
  /** Host must durably deduplicate receipt before applying the reward in its own domain. */
  onReward?: (result: RewardResult) => void | Promise<void>;
  /** Reserved banner slot height; the creative is centered inside it. No automatic refresh or overlay. */
  bannerHeight?: number;
}

const ios = Platform.OS === "ios";
// iOS 26+ renders native Liquid Glass; older iOS and Android fall back to translucent/solid surfaces.
const liquidGlass =
  ios &&
  (() => {
    try {
      return isLiquidGlassAvailable();
    } catch {
      return false;
    }
  })();
const ink = "#101820";
const mint = "#d7fbf4";

/** Render with a stable React key={presentation.ad.trackingToken}. SafeAreaProvider required. */
export function AdView(props: AdViewProps) {
  const ad = props.presentation.ad;
  const [open, setOpen] = useState(true);
  const [reduceMotion, setReduceMotion] = useState(true);
  useEffect(() => {
    let mounted = true;
    void AccessibilityInfo.isReduceMotionEnabled()
      .then((value) => {
        if (mounted) setReduceMotion(value);
      })
      .catch(() => {});
    const listener = AccessibilityInfo.addEventListener(
      "reduceMotionChanged",
      setReduceMotion,
    );
    return () => {
      mounted = false;
      listener.remove();
    };
  }, []);
  const close = () => {
    props.presentation.dismiss();
    setOpen(false);
    props.onClose();
  };
  useEffect(() => () => props.presentation.dismiss(), [props.presentation]);
  if (!open) return null;
  const content = (
    <AdContent {...props} reduceMotion={reduceMotion} onClose={close} />
  );
  return ad.format === "banner" ? (
    content
  ) : (
    <Modal
      visible
      transparent={false}
      animationType={reduceMotion ? "none" : "fade"}
      onRequestClose={close}
      presentationStyle="fullScreen"
      statusBarTranslucent
      navigationBarTranslucent
    >
      {content}
    </Modal>
  );
}

function AdContent({
  presentation,
  focused,
  onClose,
  onReward,
  bannerHeight,
  reduceMotion,
}: AdViewProps & { reduceMotion: boolean }) {
  const ad = presentation.ad;
  const banner = ad.format === "banner";
  const bounds = useWindowDimensions();
  const bannerMediaHeight = bounds.width >= 768 ? 90 : 50;
  const bannerMediaWidth = Math.min(
    bounds.width - 24,
    bounds.width >= 768 ? 728 : 320,
  );
  const insets = useSafeAreaInsets();
  const mediaRef = useRef<View>(null);
  const [foreground, setForeground] = useState(
    AppState.currentState === "active",
  );
  const [fraction, setFraction] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);
  const [ready, setReady] = useState(false);
  const countdownDurationSeconds = rewardCountdownDurationSeconds(ad);
  const [rewardSecondsLeft, setRewardSecondsLeft] = useState(
    ad.format === "rewarded" ? countdownDurationSeconds : 0,
  );
  const [rewardBusy, setRewardBusy] = useState(false);
  const [muted, setMuted] = useState(true);
  const [paused, setPaused] = useState(banner && reduceMotion);
  const granted = useRef(false);
  const spanish = ad.locale === "es";
  const canPlay =
    foreground && focused && fraction >= 0.5 && !failed && presentation.valid;
  const measure = () =>
    mediaRef.current?.measureInWindow((x, y, width, height) => {
      const area = width * height;
      const shown =
        Math.max(0, Math.min(x + width, bounds.width) - Math.max(0, x)) *
        Math.max(0, Math.min(y + height, bounds.height) - Math.max(0, y));
      setFraction(area > 0 ? shown / area : 0);
    });
  useEffect(() => {
    const listener = AppState.addEventListener("change", (state) => {
      const active = state === "active";
      presentation.setVisibility({
        foreground: active,
        focused,
        visibleFraction: fraction,
      });
      setForeground(active);
    });
    // Android's notification drawer can blur the app without changing AppState.
    // `blur`/`focus` are Android-only: subscribing on iOS raises a native
    // RCTAppState error ("not a supported event type"), a red box in dev.
    const android = Platform.OS === "android";
    const blur = android
      ? AppState.addEventListener("blur", () => {
          setForeground(false);
          presentation.setVisibility({
            foreground: false,
            focused,
            visibleFraction: fraction,
          });
        })
      : null;
    const focus = android
      ? AppState.addEventListener("focus", () =>
          setForeground(AppState.currentState === "active"),
        )
      : null;
    return () => {
      listener.remove();
      blur?.remove();
      focus?.remove();
    };
  }, [presentation, focused, fraction]);
  useEffect(() => {
    presentation.setVisibility({
      foreground,
      focused: focused && !failed,
      visibleFraction: loaded ? fraction : 0,
    });
  }, [presentation, foreground, focused, fraction, loaded, failed]);
  useEffect(() => {
    const timer = setInterval(() => {
      measure();
      presentation.tick();
      setReady(presentation.rewardReady);
      if (ad.format === "rewarded")
        setRewardSecondsLeft(
          Math.max(
            0,
            Math.ceil(countdownDurationSeconds - presentation.visibleMs / 1000),
          ),
        );
      if (!presentation.valid) onClose();
    }, 500);
    return () => clearInterval(timer);
  }, [
    presentation,
    ad,
    countdownDurationSeconds,
    bounds.width,
    bounds.height,
    onClose,
  ]);
  // Banners never play while the user prefers reduced motion; the poster stays.
  useEffect(() => {
    if (banner) setPaused(reduceMotion);
  }, [banner, reduceMotion]);
  const requestClose = () => {
    if (ad.format !== "rewarded" || presentation.rewardReady) {
      onClose();
      return;
    }
    Alert.alert(
      spanish ? "¿Cerrar el anuncio?" : "Close the ad?",
      spanish
        ? "Si cierras el anuncio antes de tiempo, no recibirás la recompensa."
        : "If you close the ad early, you will not receive the reward.",
      [
        {
          text: spanish ? "Seguir viendo" : "Keep watching",
          style: "cancel",
        },
        {
          text: spanish ? "Cerrar sin recompensa" : "Close without reward",
          style: "destructive",
          onPress: onClose,
        },
      ],
    );
  };
  const load = () => {
    presentation.rendered();
    setLoaded(true);
    measure();
  };
  const error = (kind: "load_error" | "playback_error") => {
    setFailed(true);
    presentation.error(
      kind,
      kind === "load_error" ? "load_failed" : "playback_failed",
    );
    onClose();
  };
  const openDestination = async () => {
    const url = presentation.clickUrl();
    if (!url) {
      presentation.error("redirect_error", "redirect_failed");
      return;
    }
    presentation.setVisibility({
      foreground: false,
      focused: false,
      visibleFraction: 0,
    });
    try {
      await Linking.openURL(url);
    } catch {
      presentation.error("redirect_error", "redirect_failed");
    } finally {
      presentation.setVisibility({
        foreground: AppState.currentState === "active",
        focused,
        visibleFraction: loaded ? fraction : 0,
      });
    }
  };
  const complete = async () => {
    if (rewardBusy || granted.current) return;
    setRewardBusy(true);
    try {
      const result = await presentation.completeReward();
      if (result.granted && result.receipt && onReward) {
        await onReward(result);
        granted.current = true;
        onClose();
      } else {
        Alert.alert(
          spanish ? "No se pudo confirmar" : "Could not confirm",
          spanish ? "Inténtalo de nuevo." : "Try again.",
        );
      }
    } catch {
      Alert.alert(
        spanish ? "No se pudo aplicar" : "Could not apply",
        spanish ? "Inténtalo de nuevo." : "Try again.",
      );
    } finally {
      setRewardBusy(false);
    }
  };
  const media = failed ? (
    <Text accessibilityRole="alert" style={styles.body}>
      {spanish ? "Anuncio no disponible" : "Ad unavailable"}
    </Text>
  ) : ad.mediaType === "video" ? (
    <AdVideo
      presentation={presentation}
      active={canPlay}
      paused={paused}
      muted={banner || muted}
      mediaRef={mediaRef}
      onMeasure={measure}
      onLoad={load}
      onError={() => error("playback_error")}
    />
  ) : (
    <Image
      source={{ uri: presentation.mediaUrl(ad.mediaUrl) }}
      accessibilityLabel={ad.altText}
      accessible
      contentFit="contain"
      style={styles.fill}
      onLoad={load}
      onError={() => error("load_error")}
      cachePolicy="memory"
    />
  );

  if (banner)
    // A traditional banner: the creative is the whole ad and its whole surface opens the destination.
    return (
      <View
        style={{
          minHeight: Math.max(bannerHeight ?? 0, bannerMediaHeight),
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Pressable
          accessibilityRole="link"
          accessibilityLabel={`${spanish ? "Publicidad" : "Advertisement"} · ${ad.advertiserName}. ${ad.altText}`}
          onPress={openDestination}
          ref={ad.mediaType === "image" ? mediaRef : undefined}
          collapsable={false}
          onLayout={measure}
          style={[
            { width: bannerMediaWidth, height: bannerMediaHeight },
            ios ? styles.bannerIos : undefined,
          ]}
        >
          {media}
        </Pressable>
      </View>
    );

  const label = `${spanish ? "Publicidad" : "Advertisement"} · ${ad.advertiserName}`;
  const closeLabel = spanish ? "Cerrar anuncio" : "Close ad";
  const countdown =
    ad.format === "rewarded" && !ready && !granted.current
      ? rewardSecondsLeft
      : null;
  const claim = ad.format === "rewarded" && ready && !granted.current;
  const videoControls = ad.mediaType === "video" && !failed && (
    <>
      <Control
        kind="icon"
        label={
          paused
            ? spanish
              ? "Reproducir"
              : "Play"
            : spanish
              ? "Pausar"
              : "Pause"
        }
        onPress={() => setPaused((value) => !value)}
      >
        {paused ? <PlayGlyph /> : <PauseGlyph />}
      </Control>
      <Control
        kind="icon"
        label={
          muted
            ? spanish
              ? "Activar sonido"
              : "Unmute"
            : spanish
              ? "Silenciar"
              : "Mute"
        }
        onPress={() => setMuted((value) => !value)}
      >
        <SoundGlyph muted={muted} />
      </Control>
    </>
  );
  const actions = claim ? (
    <>
      <Control
        kind="secondary"
        label={spanish ? "Info" : "Info"}
        onPress={openDestination}
      />
      <Control
        kind="primary"
        grow
        disabled={rewardBusy}
        label={
          rewardBusy
            ? spanish
              ? "Confirmando…"
              : "Confirming…"
            : spanish
              ? "Recibir recompensa"
              : "Claim reward"
        }
        onPress={complete}
      />
    </>
  ) : (
    <Control
      kind={ad.format === "rewarded" ? "secondary" : "primary"}
      grow
      label={spanish ? "Más información" : "Learn more"}
      onPress={openDestination}
    />
  );
  const backdropUrl =
    ad.posterUrl ?? (ad.mediaType === "image" ? ad.mediaUrl : undefined);

  if (ios)
    // Liquid Glass: the creative sits edge to edge over a blurred copy of itself; chrome floats above it.
    return (
      <View
        accessibilityViewIsModal
        style={[styles.fill, { backgroundColor: ink }]}
      >
        {backdropUrl && (
          <Image
            source={{ uri: presentation.mediaUrl(backdropUrl) }}
            contentFit="cover"
            blurRadius={40}
            style={styles.absolute}
            cachePolicy="memory"
            accessible={false}
            pointerEvents="none"
          />
        )}
        <View
          pointerEvents="none"
          style={[styles.absolute, { backgroundColor: "rgba(10,8,24,0.28)" }]}
        />
        <View
          style={{
            flex: 1,
            paddingTop: insets.top + 60,
            paddingBottom: insets.bottom + 66,
          }}
        >
          <Pressable
            accessibilityRole="link"
            accessibilityLabel={`${ad.altText}. ${spanish ? "Abrir destino del anuncio" : "Open ad destination"}`}
            onPress={openDestination}
            ref={ad.mediaType === "image" ? mediaRef : undefined}
            collapsable={false}
            onLayout={measure}
            style={{ flex: 1, minHeight: 30, justifyContent: "center" }}
          >
            {media}
          </Pressable>
        </View>
        <View
          style={[
            styles.row,
            styles.absoluteRow,
            { top: insets.top + 8, justifyContent: "space-between" },
          ]}
        >
          <Glass style={styles.glassLabel}>
            <View style={styles.dot} />
            <Text numberOfLines={1} style={styles.glassLabelText}>
              {label}
            </Text>
          </Glass>
          <View style={styles.row}>
            {countdown !== null && (
              <Glass style={styles.glassCountdown}>
                <Text style={styles.glassCountdownText}>{countdown} s</Text>
              </Glass>
            )}
            <Control
              kind="icon"
              label={closeLabel}
              onPress={requestClose}
              dim={countdown !== null}
            >
              <CloseGlyph />
            </Control>
          </View>
        </View>
        <View
          style={[styles.absoluteRow, { bottom: insets.bottom + 10, gap: 10 }]}
        >
          <View style={styles.row}>
            {videoControls}
            {actions}
          </View>
        </View>
      </View>
    );

  // Android: solid strips above and below the creative.
  return (
    <View
      accessibilityViewIsModal
      style={[
        styles.fill,
        {
          backgroundColor: ink,
          paddingTop: insets.top,
          paddingBottom: insets.bottom,
        },
      ]}
    >
      <View style={[styles.row, styles.androidTop]}>
        <View style={{ flex: 1, gap: 1 }}>
          <Text style={styles.androidOverline}>
            {spanish ? "Publicidad" : "Advertisement"}
          </Text>
          <Text numberOfLines={1} style={styles.androidAdvertiser}>
            {ad.advertiserName}
          </Text>
        </View>
        {countdown !== null && (
          <View style={[styles.row, styles.androidCountdown]}>
            <View style={styles.dot} />
            <Text style={styles.androidCountdownText}>{countdown} s</Text>
          </View>
        )}
        <Control
          kind="icon"
          label={closeLabel}
          onPress={requestClose}
          dim={countdown !== null}
        >
          <CloseGlyph />
        </Control>
      </View>
      <Pressable
        accessibilityRole="link"
        accessibilityLabel={`${ad.altText}. ${spanish ? "Abrir destino del anuncio" : "Open ad destination"}`}
        onPress={openDestination}
        ref={ad.mediaType === "image" ? mediaRef : undefined}
        collapsable={false}
        onLayout={measure}
        style={{ flex: 1, minHeight: 30, justifyContent: "center" }}
      >
        {media}
      </Pressable>
      <View style={styles.androidBottom}>
        <View style={styles.row}>
          {videoControls}
          {actions}
        </View>
      </View>
    </View>
  );
}

function AdVideo({
  presentation,
  active,
  paused,
  muted,
  mediaRef,
  onMeasure,
  onLoad,
  onError,
}: {
  presentation: AdPresentation;
  active: boolean;
  paused: boolean;
  muted: boolean;
  mediaRef: React.RefObject<View | null>;
  onMeasure: () => void;
  onLoad: () => void;
  onError: () => void;
}) {
  const banner = presentation.ad.format === "banner";
  const [loaded, setLoaded] = useState(false);
  const player = useVideoPlayer(
    { uri: presentation.mediaUrl(presentation.ad.mediaUrl), useCaching: false },
    (instance) => {
      instance.loop = false;
      configureNonInterruptingAdAudio(instance);
      instance.timeUpdateEventInterval = 0.5;
    },
  );
  useEffect(() => {
    if (player.status === "readyToPlay") {
      setLoaded(true);
      onLoad();
    }
    const status = player.addListener("statusChange", ({ status }) => {
      if (status === "readyToPlay") {
        setLoaded(true);
        onLoad();
      }
      if (status === "error") onError();
    });
    const time = player.addListener("timeUpdate", ({ currentTime }) =>
      presentation.videoProgress(currentTime, player.duration, player.playing),
    );
    const playing = player.addListener("playingChange", ({ isPlaying }) =>
      presentation.videoProgress(
        player.currentTime,
        player.duration,
        isPlaying,
      ),
    );
    const ended = player.addListener("playToEnd", () => {
      presentation.videoProgress(player.duration, player.duration, true);
      presentation.videoProgress(player.duration, player.duration, false);
    });
    return () => {
      status.remove();
      time.remove();
      playing.remove();
      ended.remove();
    };
  }, [player, presentation, onLoad, onError]);
  useEffect(() => {
    if (active && !paused) player.play();
    else player.pause();
  }, [player, active, paused]);
  useEffect(() => {
    player.muted = muted;
  }, [player, muted]);
  return (
    <View
      ref={mediaRef}
      collapsable={false}
      onLayout={onMeasure}
      style={styles.fill}
    >
      <VideoView
        player={player}
        style={styles.fill}
        contentFit="contain"
        nativeControls={false}
        allowsPictureInPicture={false}
        fullscreenOptions={{ enable: false }}
        accessibilityLabel={presentation.ad.altText}
      />
      {(!loaded || (banner && paused)) && presentation.ad.posterUrl && (
        <Image
          source={{ uri: presentation.mediaUrl(presentation.ad.posterUrl) }}
          contentFit="contain"
          style={styles.absolute}
          accessibilityLabel={presentation.ad.altText}
          cachePolicy="memory"
        />
      )}
    </View>
  );
}

/** Glass capsule on iOS 26+, translucent surface elsewhere. */
function Glass({
  tinted = false,
  interactive = false,
  style,
  children,
}: {
  tinted?: boolean;
  interactive?: boolean;
  style?: StyleProp<ViewStyle>;
  children: React.ReactNode;
}) {
  if (liquidGlass)
    return (
      <GlassView
        glassEffectStyle="regular"
        tintColor={tinted ? mint : undefined}
        isInteractive={interactive}
        style={[styles.glass, style]}
      >
        {children}
      </GlassView>
    );
  return (
    <View
      style={[
        styles.glass,
        tinted ? styles.glassFallbackTinted : styles.glassFallback,
        style,
      ]}
    >
      {children}
    </View>
  );
}

function Control({
  kind,
  label,
  onPress,
  disabled = false,
  dim = false,
  grow = false,
  children,
}: {
  kind: "primary" | "secondary" | "icon";
  label: string;
  onPress: () => void;
  disabled?: boolean;
  dim?: boolean;
  grow?: boolean;
  children?: React.ReactNode;
}) {
  const icon = kind === "icon";
  const primary = kind === "primary";
  const inner = icon ? (
    children
  ) : (
    <Text
      numberOfLines={1}
      style={[
        styles.controlText,
        { color: primary ? ink : "#ffffff" },
        ios ? styles.controlTextIos : styles.controlTextAndroid,
      ]}
    >
      {label}
    </Text>
  );
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ disabled }}
      disabled={disabled}
      hitSlop={icon ? 6 : 0}
      onPress={onPress}
      style={({ pressed }) => [
        grow ? { flex: 1 } : undefined,
        pressed && !disabled ? styles.pressed : undefined,
        disabled ? styles.disabled : undefined,
        dim ? styles.dim : undefined,
      ]}
    >
      {ios ? (
        <Glass
          tinted={primary}
          interactive
          style={icon ? styles.iosIcon : styles.iosButton}
        >
          {inner}
        </Glass>
      ) : (
        <View
          style={[
            icon ? styles.androidIcon : styles.androidButton,
            primary ? styles.androidFilled : styles.androidTonal,
          ]}
        >
          {inner}
        </View>
      )}
    </Pressable>
  );
}

// Glyphs are drawn with views so the adapter needs no SVG or symbol package.
function CloseGlyph() {
  return (
    <View style={styles.glyph}>
      <View style={[styles.closeBar, { transform: [{ rotate: "45deg" }] }]} />
      <View style={[styles.closeBar, { transform: [{ rotate: "-45deg" }] }]} />
    </View>
  );
}
function PlayGlyph() {
  return (
    <View style={styles.glyph}>
      <View style={styles.playTriangle} />
    </View>
  );
}
function PauseGlyph() {
  return (
    <View style={[styles.glyph, styles.row, { gap: 4 }]}>
      <View style={styles.pauseBar} />
      <View style={styles.pauseBar} />
    </View>
  );
}
function SoundGlyph({ muted }: { muted: boolean }) {
  return (
    <View style={[styles.glyph, styles.row, { gap: 3 }]}>
      <View style={styles.soundBody} />
      <View style={[styles.soundWave, { height: 8 }]} />
      <View
        style={[styles.soundWave, { height: 12, opacity: muted ? 0.3 : 1 }]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1, width: "100%", height: "100%" },
  absolute: { position: "absolute", top: 0, right: 0, bottom: 0, left: 0 },
  absoluteRow: { position: "absolute", left: 16, right: 16 },
  row: { flexDirection: "row", alignItems: "center", gap: 10 },
  body: { color: "#ffffff", fontSize: 13, opacity: 0.85 },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: mint },
  pressed: { opacity: 0.72 },
  disabled: { opacity: 0.55 },
  dim: { opacity: 0.62 },
  controlText: { fontSize: 16, textAlign: "center" },
  controlTextIos: { fontSize: 17, fontWeight: "600", letterSpacing: -0.2 },
  controlTextAndroid: { fontSize: 15, fontWeight: "600", letterSpacing: 0.1 },
  // Banner
  bannerIos: {
    borderRadius: 14,
    overflow: "hidden",
    shadowColor: "#1e143c",
    shadowOpacity: 0.22,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 8 },
  },
  // iOS chrome
  glass: { overflow: "hidden", alignItems: "center", justifyContent: "center" },
  glassFallback: {
    backgroundColor: "rgba(255,255,255,0.16)",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "rgba(255,255,255,0.35)",
  },
  glassFallbackTinted: { backgroundColor: "rgba(215,251,244,0.9)" },
  glassLabel: {
    flexDirection: "row",
    gap: 8,
    height: 36,
    paddingLeft: 12,
    paddingRight: 14,
    borderRadius: 18,
    flexShrink: 1,
  },
  glassLabelText: {
    color: "rgba(255,255,255,0.96)",
    fontSize: 13,
    fontWeight: "600",
    letterSpacing: -0.08,
    flexShrink: 1,
  },
  glassCountdown: { height: 44, paddingHorizontal: 14, borderRadius: 22 },
  glassCountdownText: {
    color: "#ffffff",
    fontSize: 15,
    fontWeight: "600",
    fontVariant: ["tabular-nums"],
  },
  iosButton: { height: 52, paddingHorizontal: 20, borderRadius: 26 },
  iosIcon: { width: 44, height: 44, borderRadius: 22 },
  // Android chrome
  androidTop: {
    height: 64,
    paddingLeft: 20,
    paddingRight: 12,
    gap: 12,
  },
  androidOverline: {
    color: "rgba(255,255,255,0.62)",
    fontSize: 11,
    fontWeight: "600",
    letterSpacing: 0.8,
    textTransform: "uppercase",
  },
  androidAdvertiser: {
    color: "rgba(255,255,255,0.92)",
    fontSize: 14,
    fontWeight: "500",
  },
  androidCountdown: {
    height: 40,
    paddingHorizontal: 14,
    borderRadius: 20,
    gap: 8,
    backgroundColor: "#24313d",
  },
  androidCountdownText: {
    color: "#ffffff",
    fontSize: 14,
    fontWeight: "600",
    fontVariant: ["tabular-nums"],
  },
  androidBottom: {
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 12,
    gap: 12,
  },
  androidButton: {
    height: 48,
    paddingHorizontal: 22,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  androidIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  androidFilled: { backgroundColor: mint },
  androidTonal: { backgroundColor: "#24313d" },
  // Glyphs
  glyph: {
    width: 20,
    height: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  closeBar: {
    position: "absolute",
    width: 16,
    height: 2,
    borderRadius: 1,
    backgroundColor: "#ffffff",
  },
  playTriangle: {
    marginLeft: 3,
    borderTopWidth: 7,
    borderBottomWidth: 7,
    borderLeftWidth: 12,
    borderTopColor: "transparent",
    borderBottomColor: "transparent",
    borderLeftColor: "#ffffff",
  },
  pauseBar: {
    width: 4,
    height: 14,
    borderRadius: 1,
    backgroundColor: "#ffffff",
  },
  soundBody: {
    width: 7,
    height: 10,
    borderRadius: 1.5,
    backgroundColor: "#ffffff",
  },
  soundWave: { width: 2, borderRadius: 1, backgroundColor: "#ffffff" },
});
