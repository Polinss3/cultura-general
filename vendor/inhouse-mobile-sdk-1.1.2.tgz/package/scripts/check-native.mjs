/** Checks the optional Expo adapter against real native packages outside the monorepo. */
import { cp, mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";

const packageRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const directory = await mkdtemp(join(tmpdir(), "inhouse-native-check-"));
const dependencies = {
  expo: "56.0.21",
  "expo-video": "56.1.4",
  "expo-image": "56.0.12",
  "expo-crypto": "56.0.5",
  "expo-glass-effect": "56.0.4",
  react: "19.2.8",
  "react-native": "0.85.3",
  "react-native-safe-area-context": "5.9.1",
  "@types/react": "19.2.18",
  typescript: "5.9.3",
};
function run(command, args) {
  return new Promise((resolveRun, reject) => {
    const child = spawn(command, args, {
      cwd: directory,
      stdio: "inherit",
      shell: false,
    });
    child.once("error", reject);
    child.once("exit", (code) =>
      code === 0
        ? resolveRun()
        : reject(new Error(`${command} exited with ${code}`)),
    );
  });
}
try {
  console.log(`Checking native SDK in temporary directory: ${directory}`);
  await writeFile(
    join(directory, "package.json"),
    JSON.stringify(
      {
        name: "inhouse-native-check",
        version: "1.0.0",
        private: true,
        type: "module",
        dependencies,
      },
      null,
      2,
    ),
  );
  await writeFile(
    join(directory, "tsconfig.json"),
    JSON.stringify(
      {
        compilerOptions: {
          target: "ES2022",
          lib: ["ES2022", "DOM"],
          module: "ESNext",
          moduleResolution: "Bundler",
          strict: true,
          esModuleInterop: true,
          skipLibCheck: true,
          noEmit: true,
          jsx: "react-jsx",
        },
        include: ["src/**/*.ts", "src/**/*.tsx"],
      },
      null,
      2,
    ),
  );
  await cp(join(packageRoot, "src"), join(directory, "src"), {
    recursive: true,
  });
  // Installation scripts are unnecessary for TypeScript and never run here.
  await run(process.platform === "win32" ? "npm.cmd" : "npm", [
    "install",
    "--ignore-scripts",
    "--no-audit",
    "--no-fund",
    "--legacy-peer-deps",
  ]);
  await run(process.execPath, [
    join(directory, "node_modules/typescript/bin/tsc"),
    "--project",
    "tsconfig.json",
  ]);
  console.log(
    "Native adapter TypeScript check passed against Expo SDK 56 packages. Device playback was not tested.",
  );
} finally {
  if (process.env.KEEP_NATIVE_CHECK_DIR === "1")
    console.log(`Keeping native check directory: ${directory}`);
  else await rm(directory, { recursive: true, force: true });
}
