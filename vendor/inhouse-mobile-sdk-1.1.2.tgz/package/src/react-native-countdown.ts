import type { ServedAd } from "./types";

type RewardTiming = Pick<
  ServedAd,
  "durationSeconds" | "mediaType" | "rewardDurationSeconds"
>;

/**
 * A rewarded video is not claimable until both its configured visible time and
 * its playback have completed. Keep the countdown aligned with that promise.
 */
export function rewardCountdownDurationSeconds(ad: RewardTiming) {
  const requiredSeconds = ad.rewardDurationSeconds ?? ad.durationSeconds ?? 5;

  return ad.mediaType === "video"
    ? Math.max(requiredSeconds, ad.durationSeconds ?? requiredSeconds)
    : requiredSeconds;
}
