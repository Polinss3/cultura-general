import { describe, expect, it } from "vitest";
import { rewardCountdownDurationSeconds } from "../src/react-native-countdown";

describe("reward countdown duration", () => {
  it("uses the full video duration when the placement threshold is shorter", () => {
    expect(
      rewardCountdownDurationSeconds({
        mediaType: "video",
        durationSeconds: 15,
        rewardDurationSeconds: 5,
      }),
    ).toBe(15);
  });

  it("keeps a longer placement threshold", () => {
    expect(
      rewardCountdownDurationSeconds({
        mediaType: "video",
        durationSeconds: 15,
        rewardDurationSeconds: 20,
      }),
    ).toBe(20);
  });

  it("uses the configured threshold for rewarded images", () => {
    expect(
      rewardCountdownDurationSeconds({
        mediaType: "image",
        durationSeconds: undefined,
        rewardDurationSeconds: 5,
      }),
    ).toBe(5);
  });
});
